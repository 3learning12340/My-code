'''Train CIFAR10 with PyTorch.'''
from __future__ import print_function

import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import torch.backends.cudnn as cudnn

import torchvision
import transforms as transforms

import os
import argparse
#from detector.dpn3d26 import *
from models.dpn3d_aaa_mix_att_group_se import *
from utils import progress_bar
from torch.autograd import Variable
import logging
import numpy as np
os.environ["CUDA_VISIBLE_DEVICES"]="2"
torch.cuda.set_device(2)
device_gpu_list=[2]
CROPSIZE = 12   # you can try 32,just try
gbtdepth = 6
fold = 5
num_desperate=1408
blklst = []#['1.3.6.1.4.1.14519.5.2.1.6279.6001.121993590721161347818774929286-388', \
    # '1.3.6.1.4.1.14519.5.2.1.6279.6001.121993590721161347818774929286-389', \
    # '1.3.6.1.4.1.14519.5.2.1.6279.6001.132817748896065918417924920957-660']
logging.basicConfig(filename='aaa_att_se_gbt_log5-'+str(fold), level=logging.INFO)     #save information to filename
parser = argparse.ArgumentParser(description='PyTorch CIFAR10 Training')
parser.add_argument('--lr', default=0.0002, type=float, help='learning rate')
parser.add_argument('--resume', '-r',default=False, action='store_true', help='resume from checkpoint')
args = parser.parse_args()

use_cuda = torch.cuda.is_available()
best_acc = 0  # best test accuracy
best_acc_gbt = 0
start_epoch = 0  # start from epoch 0 or last checkpoint epoch
# Cal mean std
preprocesspath = '/data/xiakai/DeepLung/program/DeepLung-master/nodcls/data/luna16/cls/crop_v3_size32/'
pixvlu, npix = 0, 0
for fname in os.listdir(preprocesspath):
    if fname.endswith('.npy'):
        if fname[:-4] in blklst: continue
        data = np.load(os.path.join(preprocesspath, fname))
        pixvlu += np.sum(data)
        npix += np.prod(data.shape)
        #Calculate the product of all elements in each case and add them,In a nutshell, calculate the sum of voxel   data.shape:32x32x32
pixmean = pixvlu / float(npix)
pixvlu = 0
for fname in os.listdir(preprocesspath):
    if fname.endswith('.npy'):
        if fname[:-4] in blklst: continue
        data = np.load(os.path.join(preprocesspath, fname))-pixmean
        pixvlu += np.sum(data * data)
pixstd = np.sqrt(pixvlu / float(npix))   #sqrt(((x-u)^2)/n)
# pixstd /= 255
print(pixmean, pixstd)
logging.info('mean '+str(pixmean)+' std '+str(pixstd))
# Datatransforms
logging.info('==> Preparing data..') # Random Crop, Zero out, x z flip, scale,
transform_train = transforms.Compose([
    # transforms.RandomScale(range(28, 38)),
    transforms.RandomCrop(32, padding=4),
    transforms.RandomHorizontalFlip(),
    transforms.RandomYFlip(),
    transforms.RandomZFlip(),
    transforms.ZeroOut(4),
    transforms.ToTensor(),
    transforms.Normalize((pixmean), (pixstd)), # need to cal mean and std, revise norm func
])

transform_test = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize((pixmean), (pixstd)),
])
from dataloader import lunanod
# load data list
trfnamelst = []
trlabellst = []
trfeatlst = []
tefnamelst = []
telabellst = []
tefeatlst = []
import pandas as pd
dataframe = pd.read_csv('/data/xiakai/DeepLung/program/DeepLung-master/nodcls/data/annotationdetclsconvfnl_v3.csv', \
                        names=['seriesuid', 'coordX', 'coordY', 'coordZ', 'diameter_mm', 'malignant'])
alllst = dataframe['seriesuid'].tolist()[1:]
labellst = dataframe['malignant'].tolist()[1:]
crdxlst = dataframe['coordX'].tolist()[1:]
crdylst = dataframe['coordY'].tolist()[1:]
crdzlst = dataframe['coordZ'].tolist()[1:]
dimlst = dataframe['diameter_mm'].tolist()[1:]
# test id
teidlst = []
for fname in os.listdir('/data/xiakai/DeepLung/luna16_DeepLung_Preprocess/luna16_mhd/subset'+str(fold)+'/'):
    if fname.endswith('.mhd'):
        teidlst.append(fname[:-4])
#print(teidlst)
#print(len(teidlst))  #89
mxx = mxy = mxz = mxd = 0
for srsid, label, x, y, z, d in zip(alllst, labellst, crdxlst, crdylst, crdzlst, dimlst):
    mxx = max(abs(float(x)), mxx)
    mxy = max(abs(float(y)), mxy)
    mxz = max(abs(float(z)), mxz)
    mxd = max(abs(float(d)), mxd)
    if srsid in blklst: continue
    # crop raw pixel from the center as feature
    data = np.load(os.path.join(preprocesspath, srsid+'.npy'))
    #print(data)
    #print("data.shape[0]:%r  data.shape[1]:%r   data.shape[2]:%r"%(data.shape[0],data.shape[1],data.shape[2]))
    # data.shape[0]:32  data.shape[1]:32   data.shape[2]:32
    bgx = data.shape[0]/2-CROPSIZE/2
    bgy = data.shape[1]/2-CROPSIZE/2
    bgz = data.shape[2]/2-CROPSIZE/2
    data = np.array(data[bgx:bgx+CROPSIZE, bgy:bgy+CROPSIZE, bgz:bgz+CROPSIZE])
    feat = np.hstack((np.reshape(data, (-1,)) / 255, float(d)))
    #print(feat)
    #print("feat.shape:%r"%feat.shape)
    #print("mxd:%r"%mxd)
    #[0.8        0.80392157 0.79607843... 0.50980392 0.38431373 6.27952155]
    #feat.shape:4914
    #mxd:32.27003025
    if srsid.split('-')[0] in teidlst:
        tefnamelst.append(srsid+'.npy')
        telabellst.append(int(label))
        tefeatlst.append(feat)
    else:
        trfnamelst.append(srsid+'.npy')
        trlabellst.append(int(label))
        trfeatlst.append(feat)
for idx in xrange(len(trfeatlst)):
    # trfeatlst[idx][0] /= mxx
    # trfeatlst[idx][1] /= mxy
    # trfeatlst[idx][2] /= mxz
    trfeatlst[idx][-1] /= mxd
    #print("trfeatlst[idx][-1]:%r"%trfeatlst[idx][-1])
    #trfeatlst[idx][-1]:0.17414098438906797  each of trfeatlst[idx][-1] is just one number
for idx in xrange(len(tefeatlst)):
    # tefeatlst[idx][0] /= mxx
    # tefeatlst[idx][1] /= mxy
    # tefeatlst[idx][2] /= mxz
    tefeatlst[idx][-1] /= mxd
#npypath, fnamelst, labellst, featlst, train=True,transform=None, target_transform=None,
trainset = lunanod(preprocesspath,trfnamelst, trlabellst, trfeatlst, train=True, download=True, transform=transform_train)
trainloader = torch.utils.data.DataLoader(trainset, batch_size=4, shuffle=True, num_workers=30)

testset = lunanod(preprocesspath,tefnamelst, telabellst, tefeatlst, train=False, download=True, transform=transform_test)
testloader = torch.utils.data.DataLoader(testset, batch_size=2, shuffle=False, num_workers=30)
savemodelpath = './checkpoint-'+str(fold)+'/'
# Model
if args.resume:
    # Load checkpoint.
    logging.info('==> Resuming from checkpoint..')
    assert os.path.isdir('checkpoint'), 'Error: no checkpoint directory found!'
    checkpoint = torch.load(savemodelpath+'ckpt.t7')
    net = checkpoint['net']
    best_acc = checkpoint['acc']
    start_epoch = checkpoint['epoch']
else:
    logging.info('==> Building model..')
    # net = VGG('VGG19')
    # net = ResNet18()
    # net = GoogLeNet()
    # net = DenseNet121()
    # net = ResNeXt29_2x64d()
    # net = MobileNet()
    net = DPN92_3D()
    # net = ShuffleNetG2()
neptime = 2
def get_lr(epoch):
    if epoch < 150*neptime:
        lr = 0.0002           #args.lr   0.1
    elif epoch < 250*neptime:
        lr = 0.0002         #0.01
    else:
        lr = 0.00005       #0.001
    return lr
if use_cuda:
    net.cuda()
    net = torch.nn.DataParallel(net, device_ids=device_gpu_list)   #torch.cuda.device_count())
    cudnn.benchmark = False #True

criterion = nn.CrossEntropyLoss()
#optimizer = optim.SGD(net.parameters(), lr=args.lr, momentum=0.9, weight_decay=5e-4)
optimizer = optim.Adam(net.parameters(), lr=args.lr, betas=(0.5,0.999), eps=1e-08,weight_decay=0)
from sklearn.ensemble import GradientBoostingClassifier as gbt
import pickle
# Training
def train(epoch):
    train_or_test="train"
    logging.info('\nEpoch: '+str(epoch))
    net.train()
    lr = get_lr(epoch)
    for param_group in optimizer.param_groups:
        param_group['lr'] = lr
    train_loss = 0
    correct = 0
    total = 0
    trainfeat = np.zeros((len(trfnamelst), num_desperate+CROPSIZE*CROPSIZE*CROPSIZE+1))
    trainlabel = np.zeros((len(trfnamelst),))
    idx = 0
    loss_list=[]
    flag_view_shape=True
    for batch_idx, (inputs, targets, feat) in enumerate(trainloader):
        if use_cuda:
            if flag_view_shape:
                print("train  inputs:",inputs.numpy().shape)
                print("optimizer lr: ", optimizer.param_groups[0]['lr'])
                flag_view_shape=False
            #print(len(inputs), len(targets), len(feat), type(inputs[0]), type(targets[0]), type(feat[0]))
            #16  16  16  tensor  tensor  tensor ,this is equal to batchsize=16
            #print("np.array(feat).shape:",np.array(feat).shape)  #(16,4914)  4914=17*17*17+1
            # print("np.array(targets).shape:",np.array(targets).shape)  #16
            #print("np.array(inputs).shape:",np.array(inputs).shape)  #(16,1,32,32,32)
            #print(type(targets), type(inputs), len(targets))
            # targetarr = np.zeros((len(targets),))
            # for idx in xrange(len(targets)):
                # targetarr[idx] = targets[idx]
            # print((Variable(torch.from_numpy(targetarr)).data).cpu().numpy().shape)
            inputs, targets_a, targets_b, lam = mixup_data(inputs.cuda(), targets.cuda(), alpha=1.0)
        optimizer.zero_grad()
        inputs, targets_a,targets_b = Variable(inputs), Variable(targets_a),Variable(targets_b)
        outputs, dfeat = net(inputs)
        # add feature into the array
        # print(torch.stack(targets).data.numpy().shape, torch.stack(feat).data.numpy().shape)
        # print((dfeat.data).cpu().numpy().shape)
        trainfeat[idx:idx+len(targets), :num_desperate] = np.array((dfeat.data).cpu().numpy())
        #print("dpn features:", np.array((dfeat.data).cpu().numpy()))
        for i in xrange(len(targets)):
            trainfeat[idx+i, num_desperate:] = np.array((Variable(feat[i]).data).cpu().numpy())   #raw image features
            trainlabel[idx+i] = np.array((targets[i].data).cpu().numpy())
            #print("crop features:", np.array((Variable(feat[i]).data).cpu().numpy()))
        idx += len(targets)
        #print("trainfeat.shape:",np.array(trainfeat).shape)
        loss = mixup_criterion(criterion, outputs, targets_a, targets_b, lam)
        loss.backward()
        optimizer.step()
        train_loss += loss.item()      #add many loss to one loss sum(according to batch_idx)
        _, predicted = torch.max(outputs.data, 1)
        #print("predicted:",predicted.cpu().numpy())
        #print("targets:",targets.cpu().numpy())
        #  calculate TPR,  TNR  , F1 score******************************
        total += targets.size(0)
        correct += predicted.eq(targets.data.cuda()).cpu().sum()

        progress_bar(train_or_test,batch_idx, len(trainloader), 'Loss: %.3f | Acc: %.3f%% (%d/%d)'   # create progress bar
            % (train_loss/(batch_idx+1), 100.*correct/total, correct, total))
        loss_list.append(train_loss/(batch_idx+1))


    loss_average=np.array(loss_list).mean()
    print("loss average:%r"%loss_average)
    m = gbt(max_depth=gbtdepth, random_state=0)
    m.fit(trainfeat, trainlabel)
    gbttracc = np.mean(m.predict(trainfeat) == trainlabel)
    print('ep '+str(epoch)+' tracc '+str(float(correct.numpy())/float(total))+' lr '+str(lr)+' gbtacc '+str(gbttracc))  #
    logging.info('ep '+str(epoch)+' tracc '+str(float(correct.numpy())/float(total))+' lr '+str(lr)+' gbtacc '+str(gbttracc))   #
    return m

def test(epoch, m):
    global best_acc
    global best_acc_gbt
    net.eval()
    test_loss = 0
    correct = 0
    total = 0
    testfeat = np.zeros((len(tefnamelst), num_desperate+CROPSIZE*CROPSIZE*CROPSIZE+1))
    testlabel = np.zeros((len(tefnamelst),))
    idx = 0
    P=0
    N=0
    TP=0
    FP=0
    TN=0
    FN=0
    TPR=0
    FPR=0
    F1_score=0
    train_or_test="test"
    flag_view_shape=True
    for batch_idx, (inputs, targets, feat) in enumerate(testloader):
        if use_cuda:
            if flag_view_shape:
                print("test  inputs:",inputs.numpy().shape)
                flag_view_shape=False
            inputs, targets = inputs.cuda(), targets.cuda()
        with torch.no_grad():
            inputs= Variable(inputs)
        targets=Variable(targets)
        outputs, dfeat = net(inputs)
        # add feature into the array
        testfeat[idx:idx+len(targets), :num_desperate] = np.array((dfeat.data).cpu().numpy()) #DPN features
        for i in xrange(len(targets)):
            testfeat[idx+i, num_desperate:] = np.array((Variable(feat[i]).data).cpu().numpy())  #raw image fearures
            testlabel[idx+i] = np.array((targets[i].data).cpu().numpy())   #label
        idx += len(targets)

        loss = criterion(outputs, targets)
        test_loss += loss.item()
        _, predicted = torch.max(outputs.data, 1)
        total += targets.size(0)
        correct += predicted.eq(targets.data.cuda()).cpu().sum()

        for id in range(len(predicted.cpu().numpy())):
            if (int(targets.data.cpu().numpy()[id]) == 1):
                P = P + 1
                # print("come in  p=p+1")
                if (predicted.cpu().numpy()[id] == 1):
                    TP = TP + 1
                else:
                    FN = FN + 1
            if (int(targets.data.cpu().numpy()[id]) == 0):
                N = N + 1
                # print("come in   n=n+1")
                if (predicted.cpu().numpy()[id] == 0):
                    TN = TN + 1
                else:
                    FP = FP + 1

        progress_bar(train_or_test,batch_idx, len(testloader), 'Loss: %.3f | Acc: %.3f%% (%d/%d) '
            % (test_loss/(batch_idx+1), 100.*float(correct)/float(total), correct, total))
    TPR = float(float(TP) / float(P))
    FPR = float(float(FP) / float(N))
    F1_score = float(float(2 * TP ) / float((2 * TP + FP + FN)))


    dpn_TPR = TPR
    dpn_FPR = FPR
    dpn_F1_score = F1_score
    P = 0
    N = 0
    TP = 0
    FP = 0
    TN = 0
    FN = 0
    TPR = 0
    FPR = 0
    F1_score = 0
    # print(testlabel.shape, testfeat.shape, testlabel)#, trainfeat[:, 3])
    gbtteacc = np.mean(m.predict(testfeat) == testlabel)############**************
    #print("m.predict(testfeat)",m.predict(testfeat))
    #print("testlabel",testlabel)
    for id in range(len(m.predict(testfeat))):
        if (int(testlabel[id]) == 1):
            P = P + 1
            #print("come in  p=p+1")
            if (m.predict(testfeat)[id] == 1):
                TP = TP + 1
            else:
                FN = FN + 1
        if (int(testlabel[id]) == 0):
            N = N + 1
            #print("come in   n=n+1")
            if (m.predict(testfeat)[id] == 0):
                TN = TN + 1
            else:
                FP = FP + 1
    TPR = float(float(TP) / float(P))
    FPR = float(float(FP) / float(N))
    F1_score = float(float(2 * TP ) / float((2 * TP + FP + FN)))
    DPN_TN=TN
    DPN_TP=TP
    DPN_FP=FP
    DPN_FN=FN
    if (TN+FP) > 0:
        TNR = float(float(TN)/float(TN+FP))
    else:
        TNR=0

    if TP+FP >0:
        precision=float(TP)/float(TP+FP)
    else:
        precision=0


    if gbtteacc > best_acc_gbt:
        pickle.dump(m, open('gbtmodel-'+str(fold)+'.sav', 'wb'))
        logging.info('Saving gbt ..')
        state = {
            'net': net.module if use_cuda else net,
            'epoch': epoch,
        }
        if not os.path.isdir(savemodelpath):
            os.mkdir(savemodelpath)
        torch.save(state, savemodelpath+'ckptgbt.t7')
        best_acc_gbt = gbtteacc
    # Save checkpoint.
    acc = 100.*float(correct)/float(total)
    if acc > best_acc:
        logging.info('Saving..')
        state = {
            'net': net.module if use_cuda else net,
            'acc': acc,
            'epoch': epoch,
        }
        if not os.path.isdir(savemodelpath):
            os.mkdir(savemodelpath)
        torch.save(state, savemodelpath+'ckpt.t7')
        best_acc = acc
    logging.info('Saving..')
    state = {
        'net': net.module if use_cuda else net,
        'acc': acc,
        'epoch': epoch,
    }
    if not os.path.isdir(savemodelpath):
        os.mkdir(savemodelpath)
    # if epoch % 50 == 0:
    #     torch.save(state, savemodelpath+'ckpt'+str(epoch)+'.t7')
    # best_acc = acc
    show_acc = acc
    show_best_acc = best_acc
    print('teacc ' + str(acc) + ' bestacc ' + str(best_acc) + ' gbttestaccgbt ' + str(gbtteacc) + ' bestgbt ' + str(
        best_acc_gbt) + '\n')
    print("gbt TPR: %.3f | gbt FPR: %.3f | gbt F1_SCORE: %.3f" % (TPR, FPR, F1_score))
    print("dpn TPR: %.3f | dpn FPR: %.3f | dpn F1_SCORE: %.3f" % (dpn_TPR, dpn_FPR, dpn_F1_score))
    logging.info(' DPN_TP ' + str(DPN_TP) + ' DPN_TN ' + str(DPN_TN) + ' DPN_FP ' + str(DPN_FP) + ' DPN_FN ' + str(DPN_FN) )
    logging.info(
        'teacc ' + str(show_acc) + ' bestacc ' + str(show_best_acc) + ' ccgbt ' + str(gbtteacc) + ' bestgbt ' + str(
            best_acc_gbt) + '  gbt_TPR  ' + str(TPR) + '  gbt_FPR  ' + str(FPR) + '  gbt_F1_SCORE  ' + str(
            F1_score) + '  dpn_TPR  ' + str(dpn_TPR) + '  dpn_FPR  ' + str(dpn_FPR) + '  dpn_F1_SCORE  ' + str(
            dpn_F1_score)+ '  dpn_TNR  ' + str(TNR) + '  dpn_Precision  ' + str(precision))
    assert (P == (TP + FN))

    #acc: accuracy of dpn network||bestacc: best of acc||gbtteacc:accuracy of GBT(assemble method)||best_acc_gbt:best of gbtteacc
for epoch in range(start_epoch, start_epoch+350*neptime):#200):   #all=0+350*2=700
    m = train(epoch)
    test(epoch, m)