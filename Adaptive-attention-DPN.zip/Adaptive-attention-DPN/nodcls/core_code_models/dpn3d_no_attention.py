'''Dual Path Networks in PyTorch.'''
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from torch.autograd import Variable

debug = False #True
class Bottleneck(nn.Module):
    def __init__(self, last_planes, in_planes, out_planes, dense_depth, stride, first_layer):
        super(Bottleneck, self).__init__()
        self.out_planes = out_planes
        self.dense_depth = dense_depth
        self.last_planes = last_planes
        self.in_planes = in_planes

        self.conv1 = nn.Conv3d(last_planes, in_planes, kernel_size=1, bias=False)
        self.bn1 = nn.BatchNorm3d(in_planes)
        self.conv2 = nn.Conv3d(in_planes, in_planes, kernel_size=3, stride=stride, padding=1, groups=32, bias=False)
        self.bn2 = nn.BatchNorm3d(in_planes)
        self.conv3 = nn.Conv3d(in_planes, out_planes+dense_depth, kernel_size=1, bias=False)
        self.bn3 = nn.BatchNorm3d(out_planes+dense_depth)

        self.shortcut = nn.Sequential()
        if first_layer:
            self.shortcut = nn.Sequential(
                nn.Conv3d(last_planes, out_planes+dense_depth, kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm3d(out_planes+dense_depth)
            )

    def forward(self, x):
        # print 'bottleneck_0', x.size(), self.last_planes, self.in_planes, 1
        out = F.relu(self.bn1(self.conv1(x)))
        # print 'bottleneck_1', out.size(), self.in_planes, self.in_planes, 3
        out = F.relu(self.bn2(self.conv2(out)))
        # print 'bottleneck_2', out.size(), self.in_planes, self.out_planes+self.dense_depth, 1
        out = self.bn3(self.conv3(out))
        # print 'bottleneck_3', out.size()
        x = self.shortcut(x)
        d = self.out_planes
        # print 'bottleneck_4', x.size(), self.last_planes, self.out_planes+self.dense_depth, d
        out = torch.cat([x[:,:d,:,:]+out[:,:d,:,:], x[:,d:,:,:], out[:,d:,:,:]], 1)
        #this line code corresponds with formula1 in the paper
        # print 'bottleneck_5', out.size()
        out = F.relu(out)
        return out


class ResidualBlock(nn.Module):
    def __init__(self, input_channels, output_channels, stride=1):
        super(ResidualBlock, self).__init__()
        self.input_channels = input_channels
        self.output_channels = output_channels
        self.stride = stride
        self.bn1 = nn.BatchNorm3d(input_channels)
        self.relu = nn.ReLU(inplace=True)
        self.conv1 = nn.Conv3d(input_channels, output_channels / 4, 1, 1, bias=False)
        self.bn2 = nn.BatchNorm3d(output_channels / 4)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = nn.Conv3d(output_channels / 4, output_channels / 4, 3, stride, padding=1, bias=False)
        self.bn3 = nn.BatchNorm3d(output_channels / 4)
        self.relu = nn.ReLU(inplace=True)
        self.conv3 = nn.Conv3d(output_channels / 4, output_channels, 1, 1, bias=False)
        self.conv4 = nn.Conv3d(input_channels, output_channels, 1, stride, bias=False)

    def forward(self, x):
        residual = x
        out = self.bn1(x)
        out1 = self.relu(out)
        out = self.conv1(out1)
        out = self.bn2(out)
        out = self.relu(out)
        out = self.conv2(out)
        out = self.bn3(out)
        out = self.relu(out)
        out = self.conv3(out)
        if (self.input_channels != self.output_channels) or (self.stride != 1):
            residual = self.conv4(out1)
        out += residual
        return out


# class AttentionModule_stage1_cifar(nn.Module):
#     # input size is 16*16
#     def __init__(self, in_channels, out_channels, size1=(16, 16), size2=(8, 8)):
#         super(AttentionModule_stage1_cifar, self).__init__()
#         self.first_residual_blocks = ResidualBlock(in_channels, out_channels)
#
#         self.trunk_branches = nn.Sequential(
#             ResidualBlock(in_channels, out_channels),
#             ResidualBlock(in_channels, out_channels)
#          )
#
#         self.mpool1 = nn.MaxPool3d(kernel_size=3, stride=2, padding=1)  # 8*8
#
#         self.down_residual_blocks1 = ResidualBlock(in_channels, out_channels)
#
#         self.skip1_connection_residual_block = ResidualBlock(in_channels, out_channels)
#
#         self.mpool2 = nn.MaxPool3d(kernel_size=3, stride=2, padding=1)  # 4*4
#
#         self.middle_2r_blocks = nn.Sequential(
#             ResidualBlock(in_channels, out_channels),
#             ResidualBlock(in_channels, out_channels)
#         )
#
#         self.interpolation1 = nn.Upsample(size=size2)  # 8*8
#
#         self.up_residual_blocks1 = ResidualBlock(in_channels, out_channels)
#
#         self.interpolation2 = nn.Upsample(size=size1)  # 16*16
#
#         self.conv1_1_blocks = nn.Sequential(
#             nn.BatchNorm3d(out_channels),
#             nn.ReLU(inplace=True),
#             nn.Conv3d(out_channels, out_channels, kernel_size=1, stride=1, bias=False),
#             nn.BatchNorm3d(out_channels),
#             nn.ReLU(inplace=True),
#             nn.Conv3d(out_channels, out_channels, kernel_size=1, stride=1, bias = False),
#             nn.Sigmoid()
#         )
#
#         self.last_blocks = ResidualBlock(in_channels, out_channels)
#
#     def forward(self, x):
#         x = self.first_residual_blocks(x)
#         out_trunk = self.trunk_branches(x)
#         out_mpool1 = self.mpool1(x)
#         out_down_residual_blocks1 = self.down_residual_blocks1(out_mpool1)
#         out_skip1_connection = self.skip1_connection_residual_block(out_down_residual_blocks1)
#         out_mpool2 = self.mpool2(out_down_residual_blocks1)
#         out_middle_2r_blocks = self.middle_2r_blocks(out_mpool2)
#         #
#         out_interp = self.interpolation1(out_middle_2r_blocks) + out_down_residual_blocks1
#         # print(out_skip2_connection.data)
#         # print(out_interp3.data)
#         out = out_interp + out_skip1_connection
#         out_up_residual_blocks1 = self.up_residual_blocks1(out)
#         out_interp2 = self.interpolation2(out_up_residual_blocks1) + out_trunk
#         out_conv1_1_blocks = self.conv1_1_blocks(out_interp2)
#         out = (1 + out_conv1_1_blocks) * out_trunk
#         out_last = self.last_blocks(out)
#         if debug:
#             print("out_last.size():",out_last.size())
#         return out_last

class AttentionModule_stage1(nn.Module):
    # input size is 56*56
    def __init__(self, in_channels, out_channels, size1=(56, 56), size2=(28, 28), size3=(14, 14)):
        super(AttentionModule_stage1, self).__init__()
        self.first_residual_blocks = ResidualBlock(in_channels, out_channels)

        self.trunk_branches = nn.Sequential(
            ResidualBlock(in_channels, out_channels),
            ResidualBlock(in_channels, out_channels)
         )

        self.mpool1 = nn.MaxPool3d(kernel_size=3, stride=2, padding=1)

        self.softmax1_blocks = ResidualBlock(in_channels, out_channels)

        self.skip1_connection_residual_block = ResidualBlock(in_channels, out_channels)

        self.mpool2 = nn.MaxPool3d(kernel_size=3, stride=2, padding=1)

        self.softmax2_blocks = ResidualBlock(in_channels, out_channels)

        self.skip2_connection_residual_block = ResidualBlock(in_channels, out_channels)

        self.mpool3 = nn.MaxPool3d(kernel_size=3, stride=2, padding=1)

        self.softmax3_blocks = nn.Sequential(
            ResidualBlock(in_channels, out_channels),
            ResidualBlock(in_channels, out_channels)
        )

        self.interpolation3 = nn.Upsample(size=size3,mode='trilinear',align_corners=False)

        self.softmax4_blocks = ResidualBlock(in_channels, out_channels)

        self.interpolation2 = nn.Upsample(size=size2,mode='trilinear',align_corners=False)

        self.softmax5_blocks = ResidualBlock(in_channels, out_channels)

        self.interpolation1 = nn.Upsample(size=size1,mode='trilinear',align_corners=False)

        self.softmax6_blocks = nn.Sequential(
            nn.BatchNorm3d(out_channels),
            nn.ReLU(inplace=True),  #inplace=True   to save memory
            nn.Conv3d(out_channels, out_channels , kernel_size = 1, stride = 1, bias = False),
            nn.BatchNorm3d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv3d(out_channels, out_channels , kernel_size = 1, stride = 1, bias = False),
            nn.Sigmoid()
        )

        self.last_blocks = ResidualBlock(in_channels, out_channels)

    def forward(self, x):
        x = self.first_residual_blocks(x)
        out_trunk = self.trunk_branches(x)
        out_mpool1 = self.mpool1(x)
        out_softmax1 = self.softmax1_blocks(out_mpool1)
        out_skip1_connection = self.skip1_connection_residual_block(out_softmax1)
        out_mpool2 = self.mpool2(out_softmax1)
        out_softmax2 = self.softmax2_blocks(out_mpool2)
        out_skip2_connection = self.skip2_connection_residual_block(out_softmax2)
        out_mpool3 = self.mpool3(out_softmax2)
        out_softmax3 = self.softmax3_blocks(out_mpool3)
        #
        out_interp3 = self.interpolation3(out_softmax3) + out_softmax2
        # print(out_skip2_connection.data)
        # print(out_interp3.data)
        out = out_interp3 + out_skip2_connection
        out_softmax4 = self.softmax4_blocks(out)
        out_interp2 = self.interpolation2(out_softmax4) + out_softmax1
        out = out_interp2 + out_skip1_connection
        out_softmax5 = self.softmax5_blocks(out)
        out_interp1 = self.interpolation1(out_softmax5) + out_trunk
        out_softmax6 = self.softmax6_blocks(out_interp1)
        out = (1 + out_softmax6) * out_trunk
        out_last = self.last_blocks(out)

        return out_last

class AttentionModule_stage2(nn.Module):
    # input image size is 28*28
    def __init__(self, in_channels, out_channels, size1=(28, 28), size2=(14, 14)):
        super(AttentionModule_stage2, self).__init__()
        self.first_residual_blocks = ResidualBlock(in_channels, out_channels)

        self.trunk_branches = nn.Sequential(
            ResidualBlock(in_channels, out_channels),
            ResidualBlock(in_channels, out_channels)
         )

        self.mpool1 = nn.MaxPool3d(kernel_size=3, stride=2, padding=1)

        self.softmax1_blocks = ResidualBlock(in_channels, out_channels)

        self.skip1_connection_residual_block = ResidualBlock(in_channels, out_channels)

        self.mpool2 = nn.MaxPool3d(kernel_size=3, stride=2, padding=1)

        self.softmax2_blocks = nn.Sequential(
            ResidualBlock(in_channels, out_channels),
            ResidualBlock(in_channels, out_channels)
        )

        self.interpolation2 = nn.Upsample(size=size2,mode='trilinear',align_corners=False)

        self.softmax3_blocks = ResidualBlock(in_channels, out_channels)

        self.interpolation1 = nn.Upsample(size=size1,mode='trilinear',align_corners=False)

        self.softmax4_blocks = nn.Sequential(
            nn.BatchNorm3d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv3d(out_channels, out_channels, kernel_size=1, stride=1, bias=False),
            nn.BatchNorm3d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv3d(out_channels, out_channels, kernel_size=1, stride=1, bias=False),
            nn.Sigmoid()
        )

        self.last_blocks = ResidualBlock(in_channels, out_channels)

    def forward(self, x):
        x = self.first_residual_blocks(x)
        out_trunk = self.trunk_branches(x)
        out_mpool1 = self.mpool1(x)
        out_softmax1 = self.softmax1_blocks(out_mpool1)
        out_skip1_connection = self.skip1_connection_residual_block(out_softmax1)
        out_mpool2 = self.mpool2(out_softmax1)
        out_softmax2 = self.softmax2_blocks(out_mpool2)

        out_interp2 = self.interpolation2(out_softmax2) + out_softmax1
        # print(out_skip2_connection.data)
        # print(out_interp3.data)
        out = out_interp2 + out_skip1_connection
        out_softmax3 = self.softmax3_blocks(out)
        out_interp1 = self.interpolation1(out_softmax3) + out_trunk
        out_softmax4 = self.softmax4_blocks(out_interp1)
        out = (1 + out_softmax4) * out_trunk
        out_last = self.last_blocks(out)

        return out_last

class AttentionModule_stage3(nn.Module):
    # input image size is 14*14
    def __init__(self, in_channels, out_channels, size1=(14, 14)):
        super(AttentionModule_stage3, self).__init__()
        self.first_residual_blocks = ResidualBlock(in_channels, out_channels)

        self.trunk_branches = nn.Sequential(
            ResidualBlock(in_channels, out_channels),
            ResidualBlock(in_channels, out_channels)
         )

        self.mpool1 = nn.MaxPool3d(kernel_size=3, stride=2, padding=1)
        self.softmax1_blocks = nn.Sequential(
            ResidualBlock(in_channels, out_channels),
            ResidualBlock(in_channels, out_channels)
        )

        self.interpolation1 = nn.Upsample(size=size1,mode='trilinear',align_corners=False)

        self.softmax2_blocks = nn.Sequential(
            nn.BatchNorm3d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv3d(out_channels, out_channels, kernel_size=1, stride=1, bias=False),
            nn.BatchNorm3d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv3d(out_channels, out_channels, kernel_size=1, stride=1, bias=False),
            nn.Sigmoid()
        )

        self.last_blocks = ResidualBlock(in_channels, out_channels)

    def forward(self, x):
        x = self.first_residual_blocks(x)
        out_trunk = self.trunk_branches(x)
        out_mpool1 = self.mpool1(x)
        out_softmax1 = self.softmax1_blocks(out_mpool1)

        out_interp1 = self.interpolation1(out_softmax1) + out_trunk
        out_softmax2 = self.softmax2_blocks(out_interp1)
        out = (1 + out_softmax2) * out_trunk
        out_last = self.last_blocks(out)

        return out_last

class DPN(nn.Module):
    def __init__(self, cfg):
        super(DPN, self).__init__()
        print("DPN 3D NO ATTENTION")
        in_planes, out_planes = cfg['in_planes'], cfg['out_planes']
        num_blocks, dense_depth = cfg['num_blocks'], cfg['dense_depth']

        # self.in_planes = in_planes
        # self.out_planes = out_planes
        # self.num_blocks = num_blocks
        # self.dense_depth = dense_depth

        self.conv1 = nn.Conv3d(1, 64, kernel_size=3, stride=1, padding=1, bias=False)
        self.bn1 = nn.BatchNorm3d(64)
        self.last_planes = 64
        self.layer1 = self._make_layer(in_planes[0], out_planes[0], num_blocks[0], dense_depth[0], stride=1)
        channels=out_planes[0]+dense_depth[0]*(num_blocks[0]+1)
        #self.attention_module1 = AttentionModule_stage1(in_channels=channels, out_channels=channels,
        #                                                      size1=(32, 32, 32), size2=(16, 16, 16),size3=(8,8,8))
        self.layer2 = self._make_layer(in_planes[1], out_planes[1], num_blocks[1], dense_depth[1], stride=2)
        channels = out_planes[1]+dense_depth[1]*(num_blocks[1]+1)
        #self.attention_module2 = AttentionModule_stage2(in_channels=channels, out_channels=channels,
        #                                                      size1=(16, 16, 16), size2=(8, 8, 8))
        #self.attention_module2_2 = AttentionModule_stage2(in_channels=channels, out_channels=channels,
        #                                                size1=(16, 16, 16), size2=(8, 8, 8))
        channels = out_planes[2]+dense_depth[2]*(num_blocks[2]+1)
        self.layer3 = self._make_layer(in_planes[2], out_planes[2], num_blocks[2], dense_depth[2], stride=2)
        #self.attention_module3 = AttentionModule_stage3(in_channels=channels, out_channels=channels,
        #                                                      size1=(8, 8, 8))
        #self.attention_module3_2 = AttentionModule_stage3(in_channels=channels, out_channels=channels,
        #                                                      size1=(8, 8, 8))
        #self.attention_module3_3 = AttentionModule_stage3(in_channels=channels, out_channels=channels,
        #                                                     size1=(8, 8, 8))
        self.layer4 = self._make_layer(in_planes[3], out_planes[3], num_blocks[3], dense_depth[3], stride=2)
        self.linear = nn.Linear(out_planes[3]+(num_blocks[3]+1)*dense_depth[3], 2)#10)  #2048+(3+1)*128=2560
        #print("out_planes[0-3]:",out_planes[0],out_planes[1],out_planes[2],out_planes[3])  256, 512, 1024, 2048
    def _make_layer(self, in_planes, out_planes, num_blocks, dense_depth, stride):
        strides = [stride] + [1]*(num_blocks-1)
        layers = []
        for i,stride in enumerate(strides):
            layers.append(Bottleneck(self.last_planes, in_planes, out_planes, dense_depth, stride, i==0))
            self.last_planes = out_planes + (i+2) * dense_depth
            # print '_make_layer', i, layers[-1].size()
            #last_planes:272 i=0, 304(256+16x3) i=1, 320(256+16x4) i=2.
            # last_planes:512 i=0, 608(512+32x3) i=1, 640(512+32x4) i=2. 672  i=3
            #last_planes:  1024+24x21=1528  i=19
            #last_planes:  2048+128x4=2560  i=2
        return nn.Sequential(*layers)

    def forward(self, x):
        if debug: print '0', x.size()
        out = F.relu(self.bn1(self.conv1(x)))
        if debug: print '1 ', out.size()
        out = self.layer1(out)
        if debug: print '2 ', out.size()
        #out = self.attention_module1(out)
        if debug: print ' attention module1:', out.size()
        out = self.layer2(out)
        if debug: print ' 3 ', out.size()
        #out = self.attention_module2(out)
        #out = self.attention_module2_2(out)
        if debug: print ' attention module2 and 2_2:', out.size()
        out = self.layer3(out)
        if debug: print ' 4', out.size()
        #out = self.attention_module3(out)
        #out = self.attention_module3_2(out)
        #out = self.attention_module3_3(out)
        if debug: print ' attention module3 and 3_2 and 3_3:', out.size()
        out = self.layer4(out)
        if debug: print '5', out.size()
        out = F.avg_pool3d(out, 4)
        if debug: print '6', out.size()
        out_1 = out.view(out.size(0), -1)   #change multidimensional data into one-dimensional data
        if debug: print '7', out_1.size()
        out = self.linear(out_1)
        if debug: print '8', out.size()
        return out, out_1


def DPN26():
    cfg = {
        'in_planes': (96,192,384,768),
        'out_planes': (256,512,1024,2048),
        'num_blocks': (2,2,2,2),
        'dense_depth': (16,32,24,128)
    }
    return DPN(cfg)

def DPN92_3D():
    cfg = {
        'in_planes': (96,192,384,768),
        'out_planes': (256/2,512/2,1024/2,2048/2),  #(256,512,1024,2048)  /2
        'num_blocks': (3,4,20/2,3),     #(3,4,20,3)    #(3,4,10,3)
        'dense_depth': (16,32,24,96)  #(16,32,24,128)   (16,32,24,96)
    }
    return DPN(cfg)


def test():
    debug = True
    net = DPN92_3D()
    x = Variable(torch.randn(1,1,32,32,32))
    y = net(x)
    print(y)

def mixup_data(x, y, alpha=1.0, use_cuda=True):
    '''Returns mixed inputs, pairs of targets, and lambda'''
    if alpha > 0:
        lam = np.random.beta(alpha, alpha)
    else:
        lam = 1

    batch_size = x.size()[0]
    if use_cuda:
        index = torch.randperm(batch_size).cuda()
    else:
        index = torch.randperm(batch_size)

    mixed_x = lam * x + (1 - lam) * x[index, :]
    y_a, y_b = y, y[index]
    return mixed_x, y_a, y_b, lam
def mixup_criterion(criterion, pred, y_a, y_b, lam):
    return lam * criterion(pred, y_a) + (1 - lam) * criterion(pred, y_b)


# test()
